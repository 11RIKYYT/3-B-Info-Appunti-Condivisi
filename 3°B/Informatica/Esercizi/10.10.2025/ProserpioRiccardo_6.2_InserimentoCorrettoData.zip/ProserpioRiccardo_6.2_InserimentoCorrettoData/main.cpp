/*Creare un programma che dati Anno, Mese, Giorno effettui i controlli opportuni per verificare ( step by step ) se:
l'anno � compreso tra 1900 e 2025
il mese � valido ( 1-12 )
il giorno � valido in base al mese scelto ( 28-30-31 ) */


//31 giorni: Gennaio, marzo, maggio, luglio, agosto, ottobre e dicembre.
//30 giorni: Aprile, giugno, settembre e novembre.
//28 o 29 giorni: Febbraio, che ha 29 giorni negli anni bisestili.

#include <iostream>

using namespace std;

void main()
{

	int Anno, Mese, Giorno;
	bool AnnoBisestile;
	string messaggioA, messaggioB, messaggioC;

	do
	{
		cout << "dammi l'anno da verificare:" << endl;

		cin >> Anno;

		if (Anno < 1900 || Anno > 2025)
		{
			cout << "ERRORE!: L'anno inserito non e' compreso tra 1900 e 2025" << endl;
			cout << "ri";
		}

	} while (Anno < 1900 || Anno > 2025);

	if (Anno >= 1900 && Anno <= 2025)
	{
		if (Anno % 4 == 0)
		{
			AnnoBisestile = true;
			messaggioA = "L'anno inserito e' valido ed e' bisestile";
		}

		else
		{
			AnnoBisestile = false;
			messaggioA = "L'anno inserito e' valido e non e' bisestile";
		}
	}

	do
	{
		cout << "dammi il mese da verificare:" << endl;

		cin >> Mese;

		if (Mese < 1 || Mese > 12)
		{
			cout << "ERRORE!: Il mese inserito non e' compreso tra 1 e 12" << endl;
			cout << "ri";
		}

	} while (Mese < 1 || Mese > 12);

	if (Mese >= 1 && Mese <= 12)
	{
		messaggioB = "Il mese inserito e' valido";
	}

	do
	{
		cout << "dammi il giorno da verificare:" << endl;

		cin >> Giorno;

		if (Giorno < 1 || Giorno>31)
		{
			cout << "ERRORE!: Il giorno inserito non e' compreso tra 1 e 31" << endl;
			cout << "ri";
		}

	} while (Giorno < 1 || Giorno>31);

	if (Giorno >= 1 && Giorno <= 31)
	{
		if (Mese == 1 || Mese == 3 || Mese == 5 || Mese == 7 || Mese == 8 || Mese == 10 || Mese == 12)
		{
			if (Giorno <= 31)
			{
				messaggioC = "Il giorno inserito e' valido";
			}
		}

		else if (Mese == 4 || Mese == 6 || Mese == 9 || Mese == 11)
		{
			if (Giorno == 31)
			{
				messaggioC = "Il giorno inserito non e' valido";
			}

			else
			{
				messaggioC = "Il giorno inserito e' valido";
			}
		}

		else if (Mese == 2)
		{
			if (AnnoBisestile == true)
			{
				if (Giorno <= 29)
				{
					messaggioC = "Il giorno inserito e' valido";
				}
			}

			else
			{
				if (Giorno == 29)
				{
					messaggioC = "Il giorno inserito non e' valido";
				}

				else
				{
					messaggioC = "Il giorno inserito e' valido";
				}
			}
		}
	}

	cout << messaggioA << endl;
	cout << messaggioB << endl;
	cout << messaggioC << endl;

	cout << "la data che e' stata inserita e': " << Giorno << " " << Mese << " " << Anno << endl;
}
#include <iostream>
using namespace std;
void main() {
	int giornodiora = 0, giornodinascita = 0, mesediora = 0, mesedinascita = 0, annodiora = 0, annodinascita = 0;
	cout << "Puoi mettere solo numeri" << endl;
	cout << "dammi la data di oggi in questo ordine :giorno, mese e anno" << endl;
	cin >> giornodiora;
	cin >> mesediora;
	cin >> annodiora;
	cout << "dammi la data in qui sei nato in questo ordine :giorno, mese e anno" << endl;
	cin >> giornodinascita;
	cin >> mesedinascita;
	cin >> annodinascita;
	if (annodiora - annodinascita >= 18) {
		if (mesediora - mesedinascita >= 0) {
			if (giornodiora - giornodinascita >= 0 && giornodiora<giornodinascita) {
				cout << "sei maggiorenne" << endl;
				
			}
			else {
				cout << "sei minorenne" << endl;
			}
		}
		else {
			cout << "sei minorenne" << endl;
		}
	}
	else {
		cout << "sei minorenne" << endl;
	}


}

#include <iostream>
using namespace std;

void main() {
	int latoa, latob, latoc, somma = 0;
	string messaggio;


	cout << "dammi il valore dei tre lati" << endl;
	cout << "dammi il valore del lato A" << endl;
	cin >> latoa;
	cout << "dammi il valore del lato B" << endl;
	cin >> latob;
	cout << "dammi il valore del lato C" << endl;
	cin >> latoc;


	if (latoa > latob && latoa > latoc) {
		somma = latob + latoc;
		if (somma > latoa) {
			messaggio = "e possibile che sia un triangolo";
		}
		else {
			messaggio = "non e possibile che sia un triangolo";
		}
	}
	if (latob > latoa && latob > latoc) {
		somma = latoa + latoc;
		if (somma > latob) {
			messaggio = "e possibile che sia un triangolo";
		}
		else {
			messaggio = "non e possibile che sia un triangolo";
		}
	}
	if (latoc > latob && latoa < latoc) {
		somma = latob + latoa;
		if (somma > latoc) {
			messaggio = "e possibile che sia un triangolo";
		}
		else {
			messaggio =  "non e possibile che sia un triangolo";
		}
	}


	cout << messaggio << endl;


}


#include <iostream>
#include <string>
using namespace std;
void main()
{
    int  numerodigiorni = 0, numerodikilometri = 0, costototale=0, costopergiorno=100, costodeigiorni=0;
        string messaggio;
    cout << "Salve vorrei chiederle per quanto a noleggiato la nostra autovettura?"<<endl;
    cin >> numerodigiorni;
    cout << "Vorrei chiederle anche quanti kilometri a percorso con essa" << endl;
    cin >> numerodikilometri;

    if (numerodikilometri <= 150) {
        costodeigiorni = numerodigiorni * costopergiorno;
        costototale = costodeigiorni;
        messaggio = "Il costo totale e " + to_string(costototale);
    }
    if(numerodikilometri>=151 && numerodigiorni<=500){
        costodeigiorni = numerodigiorni * costopergiorno;
        costototale = (numerodikilometri * 0.1) + costodeigiorni;
        messaggio = "Il costo totale e " + to_string(costototale);
    }
    if (numerodigiorni <= 501) {
        costodeigiorni = numerodigiorni * costopergiorno;
        costototale = (numerodikilometri * 0.08) + costodeigiorni;
        messaggio = "Il costo totale e " + to_string(costototale);
    }
    cout << messaggio;

}

/*Mario, il manager del supermercato deve decidere quante casse aprire in base alle persone che sono all'interno del supermercato.
Mario vuole dividere in modo preciso le persone nelle casse ( tutte le file devono avere esattamente lo stesso numero di persone! ) 
Creare un programma che, dato il numero di persone all'inteno del supermercato,  aiuti mario a capire quante casse aprire considerando
che il supermercato che gestisce ha a disposizione 5 casse.
esempio:
25 persone -> 5 casse
22 persone -> 2 casse
20 persone -> 4 casse
10 persone -> 5 casse
9 persone -> 3 casse
11 persone -> 1 cassa
*/

#include <iostream>
#include <string>

using namespace std;

void main()
{

	int CasseADisposizione = 5, nPersone;
	string messaggio;

	cout << "dimmi quante persone sono presenti in questo momento all'interno del supermercato" << endl;
	cin >> nPersone;

	while (CasseADisposizione>0)
	{
		if (nPersone%CasseADisposizione == 0)
		{
			messaggio = "Numero di casse utilizzate: " + to_string(CasseADisposizione);

			cout << messaggio << endl;

			break;
		}

		else
		{
			CasseADisposizione = CasseADisposizione - 1;
		}

	}

}
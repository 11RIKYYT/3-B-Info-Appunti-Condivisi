/*Mario, il manager del supermercato deve decidere quante casse aprire in base alle persone che sono all'interno del supermercato.
Mario vuole dividere in modo preciso le persone nelle casse ( tutte le file devono avere esattamente lo stesso numero di persone! ) 
Creare un programma che, dato il numero di persone all'inteno del supermercato,  aiuti mario a capire quante casse aprire considerando
che il supermercato che gestisce ha a disposizione 5 casse.
esempio:
25 persone -> 5 casse
22 persone -> 2 casse
20 persone -> 4 casse
10 persone -> 5 casse
9 persone -> 3 casse
11 persone -> 1 cassa*/

#include <iostream>
#include <string>

using namespace std;

void main()
{
	int nPersone, CasseDaAprire, CasseADisposizione = 5, CinqueCasse, QuattroCasse, TreCasse, DueCasse, UnaCassa;
	string messaggio;

	cout << "dammi il numero di persone presenti attualmente all'interno del supermercato" << endl;
	cin >> nPersone;

	CinqueCasse = (nPersone % 5) == 0;
	QuattroCasse = (nPersone % 4) == 0;
	TreCasse = (nPersone % 3) == 0;
	DueCasse = (nPersone % 2) == 0;
	UnaCassa = (nPersone % 1) == 0;

	if (CinqueCasse)
	{
		CasseDaAprire = 5;

		messaggio = "Le casse da aprire sono: " + to_string(CasseDaAprire);
	}

	else if (QuattroCasse)
	{
		CasseDaAprire = 4;

		messaggio = "Le casse da aprire sono: " + to_string(CasseDaAprire);
	}

	else if (TreCasse)
	{
		CasseDaAprire = 3;

		messaggio = "Le casse da aprire sono: " + to_string(CasseDaAprire);
	}

	else if (DueCasse)
	{
		CasseDaAprire = 2;

		messaggio = "Le casse da aprire sono: " + to_string(CasseDaAprire);
	}

	else if (UnaCassa)
	{
		CasseDaAprire = 1;

		messaggio = "Le casse da aprire sono: " + to_string(CasseDaAprire);
	}

	cout<<messaggio;

}
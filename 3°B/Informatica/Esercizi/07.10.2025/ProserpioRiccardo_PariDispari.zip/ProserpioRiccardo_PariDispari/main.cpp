/*Determina se i seguenti numeri sono pari o dispari*/

#include <iostream>

using namespace std;

void main()
{
	int NumeroDaControllatre;
	string messaggio;

	cout << "dammi il numero da controllare" << endl;
	cin >> NumeroDaControllatre;

	int resto = NumeroDaControllatre % 2;

	if (resto == 0)
	{
		messaggio = "il numero e' pari";
	}

	else
	{
		messaggio = "il numero e' dispari";
	}

	cout << messaggio;
}
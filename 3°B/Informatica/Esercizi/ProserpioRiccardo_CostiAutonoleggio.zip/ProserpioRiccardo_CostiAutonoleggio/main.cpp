#include <iostream>
#include <string>

using namespace std;

void main()
{

	int Costi_Fissi = 100, KmPercorsi, Costi_1, Costi_2;
	double PrezzoAKm1 = 0.1, PrezzoAKm2 = 0.8;
	string messaggio;

	cout << "Inserire quanti kilometri si hanno percorso con l'auto noleggiata: " << endl;

	cin >> KmPercorsi;

	if (KmPercorsi <= 150)
	{
		messaggio = "I costi di noleggio dell'autovettura sono: " + to_string(Costi_Fissi);
	}

	else
	{
		if (KmPercorsi > 150 && KmPercorsi <= 500)
		{
			Costi_1 = (KmPercorsi * PrezzoAKm1) + Costi_Fissi;
			messaggio = "I costi di noleggio dell'autovettura sono: " + to_string(Costi_1);
		}

		else
		{
			if (KmPercorsi > 500)
			{
				Costi_2 = (KmPercorsi * PrezzoAKm2) + Costi_Fissi;
				messaggio = "I costi di noleggio dell'autovettura sono : " + to_string(Costi_2);
			}
		}
	}

	cout << messaggio;

}
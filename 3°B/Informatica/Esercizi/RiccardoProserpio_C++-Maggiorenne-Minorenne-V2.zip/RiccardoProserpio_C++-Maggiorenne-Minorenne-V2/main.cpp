#include <iostream>

using namespace std;

void main()
{
	int giornoC, meseC, annoC, giornoDN, meseDN, annoDN;

	cout << "inserisci la data attuale seguendo questo formato: DD MM YYYY" << endl;
	cin >> giornoC;
	cin >> meseC;
	cin >> annoC;

	cout << "inserisci la data completa in cui sei nato seguendo questo formato: DD MM YYYY" << endl;
	cin >> giornoDN;
	cin >> meseDN;
	cin >> annoDN;

	int anno = (annoC - annoDN);

	if (anno >= 18)
	{
		if (meseDN <= meseC)
		{
			if (giornoDN <= giornoC)
			{
				cout << "Sei maggiorenne" << endl;
			}

			else
			{
				cout << "Sei minorenne" << endl;
			}

		}
			
		else
		{
			cout << "Sei minorenne" << endl;
		}

		
	}
	else
	{
		cout << "Sei minorenne" << endl;
	}
}
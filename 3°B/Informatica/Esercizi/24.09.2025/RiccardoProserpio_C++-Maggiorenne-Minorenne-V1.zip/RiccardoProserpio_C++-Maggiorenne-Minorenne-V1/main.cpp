#include <iostream>

using namespace std;

void main()
{
	int anno;

	cout << "In che anno sei nato?"<<endl;
	cin >> anno;

	int datacorrente = (2025 - anno);

	if (datacorrente>=18)
	{
		cout << "Sei maggiorenne" << endl;
	}

	else
	{
		cout << "Sei minorenne" << endl;
	}
}
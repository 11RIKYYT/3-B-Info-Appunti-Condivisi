#include <iostream>

using namespace std;

void main()
{
	int Lato_A, Lato_B, Lato_C;
	string messaggio;

	cout << "Dammi i valori dei lati con cui vorresti costuire il triangolo" << endl;
	cin >> Lato_A;
	cin >> Lato_B;
	cin >> Lato_C;

	if (Lato_A < Lato_C && Lato_B < Lato_C)
	{
		if ((Lato_A + Lato_B) > Lato_C)
		{
			messaggio = "si, e' possibile costruire un triangolo date questi valori." << endl;
		}

		else
		{
			messaggio = "No, non e' possibile costruire un triangolo date questi valori." << endl;
		}
		
	}

	else

		if (Lato_A < Lato_B && Lato_C < Lato_B)
		{
			if ((Lato_A + Lato_C) > Lato_B)
			{
				messaggio = "si, e' possibile costruire un triangolo date questi valori." << endl;
			}

			else
			{
				messaggio = "No, non e' possibile costruire un triangolo date questi valori." << endl;
			}
			
		}
		
		else

			if (Lato_B < Lato_A && Lato_C < Lato_A)
			{
				if ((Lato_B + Lato_C) > Lato_A)
				{
					messaggio = "si, e' possibile costruire un triangolo date questi valori." << endl;
				}

				else
				{
					messaggio = "No, non e' possibile costruire un triangolo date questi valori." << endl;
				}
			}
	
	cout << messaggio << endl;
}